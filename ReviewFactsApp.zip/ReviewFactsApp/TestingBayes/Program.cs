﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using webforms;

namespace TestingBayes
{
    public class Program
    {
        static string pattern = "Am avut o experienta cu aceasta firma, ";
        public static List<string> ListOfReviews = new List<string>
        {
            pattern + "am comandat o masa, care a iesit cum ma asteptam. Recomand!", // 1 cuvant mobila
            pattern + "mi-au construit o cabana de vara, duritatea betonului a iesit cam slaba.", // 1 cuvant constructii
            pattern + "mi-au construit un put de mare adancime, cu tuburi de 60 de cm.", // 1 cuvant foraje fantani
            pattern + "au facut o finisare la o masa, care a iesit cum ma asteptam. Recomand!", // 1 cuv constructii, 1 cuvant mobila
            pattern + "mi-au turnat beton pe o terasa, pe care au amenajat o masa si o " +
            "comoda si a iesit cum ma asteptam. Recomand!", // cate un cuvant din fiecare categorie
            pattern + "mi-au realizat o cabana din caramida si beton, si au turnat o masa de tenis, care au iesit cum ma asteptam. Recomand!", // 2 cuv constructii, 1 cuvant mobila
            pattern + "mi-au turnat un trotuar de beton langa fantana si au lucrat bine. Recomand!", // 2 cuv constructii, 1 cuvant foraje fantani
            pattern + "au sapat un put de mare adancime, si au placat-o cu caramida. Au lucrat bine." //1 cuv fantani, 1 cuv constructii
        };

        public static List<string> ExpectedClassifications = new List<string>()
        {
            "mobila",
            "constructii",
            "foraje fantani",
            "mobila",
            "constructii",
            "constructii",
            "constructii",
            "foraje fantani"
        };

        static void Main(string[] args)
        {
            Dictionary<int, string> ClassifiedCategories = new Dictionary<int, string>();

            foreach (var item in ListOfReviews)
            {
                ClassifiedCategories.Add(ListOfReviews.IndexOf(item), _Default.Classify(item, _Default.TrainingDictionaryDataReviews));
            }

            for (int i = 0; i < ExpectedClassifications.Count; i++)
            {
                Console.WriteLine($"Expected: {i} -> {ExpectedClassifications[i]} ------- Classified: {ClassifiedCategories.ElementAt(i).Value}");
            }

        }
    }
}
