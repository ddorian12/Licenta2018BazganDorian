﻿using Contextul;
using System;
using System.Linq;

namespace webforms
{
    public partial class review : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            nume_textbox.Enabled = false;
            prenume_textbox.Enabled = false;
        }

        protected void AddReviewButton_Click(object sender, EventArgs e)
        {
            var id = int.Parse(Request.QueryString["id"]);
            using (var db = new TheContext())
            {
                var alias = prenume_textbox.Text;
                var comment = TextArea1.Value;
                var rating = rblMeasurementSystem.SelectedValue;
                var intRating = int.Parse(rating);

                if (AnonimOption.Checked)
                {
                    var review = new Review
                    {
                        FirmaId = id,
                        UserId = viewreviews.SessionUserId,
                        Comment = comment,
                        NrStele = intRating,
                        Alias = alias
                    };
                    db.Reviews.Add(review);
                    db.SaveChanges();
                }
                else
                {
                    var anonimReview = new Review
                    {
                        FirmaId = id,
                        UserId = viewreviews.SessionUserId,
                        Comment = comment,
                        NrStele = intRating
                    };
                    db.Reviews.Add(anonimReview);
                    db.SaveChanges();
                }
            }
            nume_textbox.Text = string.Empty;
            prenume_textbox.Text = string.Empty;
            TextArea1.Value = string.Empty;
            Label1.Text = "Review-ul a fost adaugat cu succes!";
            Response.AddHeader("REFRESH", "2;URL=viewreviews.aspx?id=" + id);
        }
    }
}
