﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using Contextul;

namespace webforms
{
    public partial class CategoryReviews : System.Web.UI.Page
    {
        public List<Firma> GetFirmas()
        {
            var id = int.Parse(Request.QueryString["id"]);
            using (var db = new TheContext())
            {
                var firme = (from f in db.Firme
                    where f.Categorie.CategoryId == id
                    select f).ToList();
                return firme;
            }
        }

        public IEnumerable<Review> GetReviewsForCategory()
        {
            var firme = GetFirmas();
            var reviews = new List<Review>();
            var allReviews = new List<Review>();

            var context = new TheContext();
            foreach (var firma in firme)
            {
                reviews = (from r in context.Reviews
                    where r.FirmaId == firma.FirmaId
                    select r).ToList();
                allReviews.AddRange(reviews);
            }
            context.Dispose();

            return allReviews;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            var revs = GetReviewsForCategory();
            
            foreach (var rev in revs)
            {
                var reviewId = rev.ReviewId;
                //randul 1
                TableRow row1 = new TableRow();

                //celula1
                TableCell cell1 = new TableCell();
                //cell1.CssClass = "first-cell";
                Control ctrl1 = new Control();
                ctrl1 = new Label();
                ((Label)ctrl1).CssClass = "formLabel";
                ((Label)ctrl1).Text = "Nume utilizator: ";
                ((Label)ctrl1).Font.Bold = true;
                cell1.Controls.Add(ctrl1);
                row1.Cells.Add(cell1);

                //celula2
                TableCell cell2 = new TableCell();
                Control ctrl2 = new Control();
                ctrl2 = new Label();
                ((Label)ctrl2).CssClass = "formLabel";
                if (rev.Alias != null)
                {
                    ((Label)ctrl2).Text = rev.Alias;
                }
                else
                {
                    using (var db = new TheContext())
                    {
                        var userLastName = (from p in db.Users
                                            where p.UserId == rev.UserId
                                            select p.LastName).SingleOrDefault();
                        var userFirstName = (from p in db.Users
                                             where p.UserId == rev.UserId
                                             select p.FirstName).SingleOrDefault();

                        ((Label)ctrl2).Text = userLastName + " " + userFirstName;
                    }
                }
                ((Label)ctrl2).Font.Bold = true;
                cell2.Controls.Add(ctrl2);
                row1.Cells.Add(cell2);

                //randul 2
                TableRow row2 = new TableRow();

                //celula 3
                TableCell cell3 = new TableCell();
                Control ctrl3 = new Control();
                ctrl3 = new Label();
                ((Label)ctrl3).CssClass = "formLabel";
                ((Label)ctrl3).Text = "Comentariu: ";
                ((Label)ctrl3).Font.Bold = true;
                cell3.Controls.Add(ctrl3);
                row2.Cells.Add(cell3);

                //celula4
                TableCell cell4 = new TableCell();
                Control ctrl4 = new Control();

                ctrl4 = new TextBox();
                ((TextBox)ctrl4).CssClass = "form-control comment-textbox";
                ((TextBox)ctrl4).Text = rev.Comment;
                ((TextBox)ctrl4).Font.Bold = true;
                ((TextBox)ctrl4).TextMode = TextBoxMode.MultiLine;
                ((TextBox)ctrl4).ReadOnly = true;

                Control ctrlx = new Control();
                ctrlx = new ImageButton();
                ((ImageButton)ctrlx).ImageUrl = "images/like.png";
                ((ImageButton)ctrlx).CssClass = "like-image";
                ((ImageButton) ctrlx).Enabled = false;
                ((ImageButton)ctrlx).Style.Add(HtmlTextWriterStyle.Cursor, "not-allowed");

                Control ctrly = new Control();
                ctrly = new Label();
                ((Label)ctrly).CssClass = "like-count";

                using (var db = new TheContext())
                {
                    int countLikes = 0;

                    var likes = (from l in db.LikedReviews
                                 where l.ReviewId == reviewId
                                 select l.Like).ToList();

                    if (likes.Count == 0)
                    {
                        countLikes = 0;
                    }
                    else
                    {
                        for (int i = 0; i < likes.Count; i++)
                        {
                            countLikes++;
                        }
                    }
                    ((Label)ctrly).Text = countLikes.ToString();
                }


                cell4.Controls.Add(ctrl4);
                cell4.Controls.Add(ctrlx);
                cell4.Controls.Add(ctrly);
                row2.Cells.Add(cell4);

                //randul 3
                TableRow row3 = new TableRow();

                TableCell cell5 = new TableCell();
                Control ctrl5 = new Control();
                ctrl5 = new Label();
                ((Label)ctrl5).CssClass = "formLabel";
                ((Label)ctrl5).Text = "Scor: ";
                ((Label)ctrl5).Font.Bold = true;

                cell5.Controls.Add(ctrl5);
                row3.Cells.Add(cell5);



                TableCell cell6 = new TableCell();
                Control ctrl6 = new Control();
                ctrl6 = new Label();
                ((Label)ctrl6).CssClass = "formLabel";
                int nr_stele = rev.NrStele;
                switch (nr_stele)
                {
                    case 1:
                        ((Label)ctrl6).Text = "<img src='images/rsz_1star.png'/>";
                        break;
                    case 2:
                        ((Label)ctrl6).Text = "<img src='images/rsz_2star.png'/>";
                        break;
                    case 3:
                        ((Label)ctrl6).Text = "<img src='images/rsz_3star.png'/>";
                        break;
                    case 4:
                        ((Label)ctrl6).Text = "<img src='images/rsz_4star.png'/>";
                        break;
                    case 5:
                        ((Label)ctrl6).Text = "<img src='images/rsz_5star.png'/>";
                        break;
                }

                ((Label)ctrl6).Font.Bold = true;
                cell6.Controls.Add(ctrl6);
                row3.Cells.Add(cell6);

                TableRow row4 = new TableRow();
                row4.BackColor = ColorTranslator.FromHtml("#333");

                TableCell cell7 = new TableCell();
                cell7.BorderColor = ColorTranslator.FromHtml("#333");
                row4.Cells.Add(cell7);

                TableCell cell8 = new TableCell();
                cell8.BorderColor = ColorTranslator.FromHtml("#333");

                row4.Cells.Add(cell8);

                tablerevCategories.Rows.Add(row1);
                tablerevCategories.Rows.Add(row2);
                tablerevCategories.Rows.Add(row3);
                tablerevCategories.Rows.Add(row4);
            }
        }
    }
}