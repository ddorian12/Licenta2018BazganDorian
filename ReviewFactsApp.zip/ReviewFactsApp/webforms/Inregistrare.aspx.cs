﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Contextul;

namespace webforms
{
    public partial class Inregistrare : System.Web.UI.Page
    {
        static byte[] GenerateSaltedHash(byte[] plainText, byte[] salt)
        {
            HashAlgorithm algorithm = new SHA256Managed();

            byte[] plainTextWithSaltBytes = new byte[plainText.Length + salt.Length];

            for (int i = 0; i < plainText.Length; i++)
            {
                plainTextWithSaltBytes[i] = plainText[i];
            }

            for (int i = 0; i < salt.Length; i++)
            {
                plainTextWithSaltBytes[plainText.Length + i] = salt[i];
            }
            return algorithm.ComputeHash(plainTextWithSaltBytes);
        }

        //salt-ul de atasat inaintea parolei
        private static byte[] CreateSalt(int size)
        {
            //Genereaza un numar cryptografic random
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            byte[] buff = new byte[size];
            rng.GetBytes(buff);

            return buff;
        }

        static byte[] ConvertPlainTextToBytes(string plainText)
        {
            return Encoding.UTF8.GetBytes(plainText);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //
        }
        protected void submit_btn_Click(object sender, EventArgs e)
        {
            var nume = nume_textbox.Text;
            var prenume = prenume_textbox.Text;
            var email = email_textbox.Text;

            var parola = passwd_textbox.Text;

            var isPasswordStrength = PasswordAdvisor.CheckStrength(parola);
            var hasOptimumLength = PasswordAdvisor.CheckLength(parola);

            if (isPasswordStrength && hasOptimumLength)
            {
                var bytedPassword = ConvertPlainTextToBytes(parola);

                byte[] salt = CreateSalt(5);

                var finalEncryptedPassword = GenerateSaltedHash(bytedPassword, salt);
                var finalEncryptedPasswordString = Convert.ToBase64String(finalEncryptedPassword);


                using (var db = new TheContext())
                {
                    var _email = (from u in db.Users
                        where u.Email == email
                        select u.Email).SingleOrDefault();
                    if (_email != null)
                    {
                        successregister_lbl.Text = "Exista deja un cont cu email-ul introdus!";
                    }
                    else
                    {
                        var user = new User { LastName = nume, FirstName = prenume, Email = email, Password = finalEncryptedPasswordString, Salt = salt };
                        db.Users.Add(user);
                        db.SaveChanges();
                        successregister_lbl.Text = "Te-ai inregistrat cu succes!";
                        Response.AddHeader("REFRESH", "2;URL=Logare.aspx");
                    }
                }
            }
            else
            {
                if(!isPasswordStrength)
                {
                    successregister_lbl.Text =
                        "Parola trebuie sa contina o combinatie de caractere mari, mici, cifre si simboluri!";
                }
                if(!hasOptimumLength)
                {
                    successregister_lbl.Text =
                        "Parola trebuie sa contina intre 6 si 20 de caractere!";
                }
            }

        }
    }

    public class PasswordAdvisor
    {
        public static bool CheckStrength(string password)
        {
            string patdi = @"\d+"; //match digits
            string patupp = @"[A-Z]+"; //match upper cases
            string patlow = @"[a-z]+"; //match lower cases
             
            Match id = Regex.Match(password, patdi);
            Match upp = Regex.Match(password, patupp);
            Match low = Regex.Match(password, patlow);

            if (id.Success && upp.Success && low.Success)
            {
                return true;
            }

            return false;
        }

        public static bool CheckLength(string password)
        {
            var passwordCharArray = password.ToCharArray();
            bool hasRequiredLength = passwordCharArray.Length >= 6 && passwordCharArray.Length <= 20;

            if (hasRequiredLength)
            {
                return true;
            }
            return false;
        }
    }
}