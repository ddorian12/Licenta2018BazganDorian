﻿using Contextul;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.UI.WebControls;

namespace webforms
{
    public partial class Logare : System.Web.UI.Page
    {
        static byte[] GenerateSaltedHash(byte[] plainText, byte[] salt)
        {
            HashAlgorithm algorithm = new SHA256Managed();

            byte[] plainTextWithSaltBytes = new byte[plainText.Length + salt.Length];

            for (int i = 0; i < plainText.Length; i++)
            {
                plainTextWithSaltBytes[i] = plainText[i];
            }

            for (int i = 0; i < salt.Length; i++)
            {
                plainTextWithSaltBytes[plainText.Length + i] = salt[i];
            }
            return algorithm.ComputeHash(plainTextWithSaltBytes);
        }

        static byte[] ConvertPlainTextToBytes(string plainText)
        {
            return Encoding.UTF8.GetBytes(plainText);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["USER_EMAIL"] != null)
            {
                succes_lbl.Text = "Esti deja logat!";
                email_textbox.ReadOnly = true;
                passwd_textbox.ReadOnly = true;
                submit_btn.Enabled = false;
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            var insertedEmail = email_textbox.Text;
            var passwd2 = passwd_textbox.Text;

            using (var db = new TheContext())
            {
                var checkedEmail = (from u in db.Users
                                    where u.Email == insertedEmail
                                    select u.Email).SingleOrDefault();

                if (checkedEmail != null)
                {
                    var salt = (from u in db.Users
                                where u.Email == insertedEmail
                                select u.Salt).SingleOrDefault();

                    var bytedPasswd = ConvertPlainTextToBytes(passwd2);
                    var bytedCheckPassword = GenerateSaltedHash(bytedPasswd, salt);
                    var checkPassword = Convert.ToBase64String(bytedCheckPassword);

                    var checkedPassword = (from u in db.Users
                                           where u.Email == insertedEmail
                                           where u.Password == checkPassword
                                           select u.Password).SingleOrDefault();

                    if (checkedPassword != null)
                    {
                        Session["USER_EMAIL"] = insertedEmail;
                        Response.Redirect("Default.aspx");
                    }
                    else
                    {
                        succes_lbl.Text = "Parola introdusa gresit!";
                    }
                }
                else
                {
                    succes_lbl.Text = "Email-ul introdus nu corespunde unui cont!";
                }
            }
        }
    }
}