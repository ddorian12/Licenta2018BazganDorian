﻿using Contextul;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace webforms
{
    public partial class viewreviews : Page
    {
        public static string SessionLastName { get; set; }
        public static string SessionFirstName { get; set; }
        public static int SessionUserId { get; set; }


        public string LoggedUserEmail
        {
            get { return Session["USER_EMAIL"].ToString(); }
            set { LoggedUserEmail = value; }
        }

        public int CountForLikes { get; set; }

        public void GetLastName()
        {
            using (var db = new TheContext())
            {
                SessionLastName = (from p in db.Users
                                   where p.Email == LoggedUserEmail
                                   select p.LastName).SingleOrDefault();
            }
        }

        public void GetFirstName()
        {
            using (var db = new TheContext())
            {
                SessionFirstName = (from p in db.Users
                                    where p.Email == LoggedUserEmail
                                    select p.FirstName).SingleOrDefault();
            }
        }

        public int GetUserId()
        {
            using (var db = new TheContext())
            {
                SessionUserId = (from p in db.Users
                                 where p.Email == LoggedUserEmail
                                 select p.UserId).SingleOrDefault();
                return SessionUserId;
            }
        }

        public List<Review> SelectReviewFirma(int id)
        {
            using (var db = new TheContext())
            {
                var review = (from r in db.Reviews
                              where r.FirmaId == id
                              where r.Approved == 1
                              select r).ToList();
                return review;
            }
        }

        public bool CanSubmit(int userId)
        {
            using (var db = new TheContext())
            {
                var id = int.Parse(Request.QueryString["id"]);
                var review = (from r in db.Reviews
                              where r.FirmaId == id
                              where r.UserId == SessionUserId
                              select r).SingleOrDefault();
                if (review != null)
                {
                    return false;
                }
                return true;
            }
        }

        public bool AlreadyLiked(int usrId, int btnId)
        {
            using (var db = new TheContext())
            {
                var existingLikedReview = (from r in db.LikedReviews
                                           where r.UserId == usrId
                                           where r.ReviewId == btnId
                                           select r).SingleOrDefault();
                if (existingLikedReview != null)
                {
                    return true;
                }
            }
            return false;
        }

        public LikedReview ReturnExistLikedReview(int usrId, int btnId)
        {
            using (var db = new TheContext())
            {
                var existingLikedReview = (from r in db.LikedReviews
                    where r.UserId == usrId
                    where r.ReviewId == btnId
                    select r).SingleOrDefault();
                return existingLikedReview;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["USER_EMAIL"] != null)
            {
                GetFirstName();
                GetLastName();
                GetUserId();
            }
            using (var db = new TheContext())
            {
                var email = (from u in db.Users
                             where u.AccessMember == "admin"
                             select u.Email).SingleOrDefault();

                if (Session["USER_EMAIL"] != null)
                {
                    if (Session["USER_EMAIL"].ToString() == email)
                    {
                        admin_btn.Visible = true;
                    }
                    else
                    {
                        admin_btn.Visible = false;
                    }
                }
                else
                {
                    admin_btn.Visible = false;
                }
            }


            if (!CanSubmit(SessionUserId))
            {
                addreview_btn.Enabled = false;
                addreview_btn.ToolTip = "Ai adăugat deja un review!";
            }

            var _id = int.Parse(Request.QueryString["id"]);
            var revs = SelectReviewFirma(_id);

            foreach (var item in revs)
            {
                var reviewId = item.ReviewId;

                //randul 1
                TableRow row1 = new TableRow();

                //celula1
                TableCell cell1 = new TableCell();
                //cell1.CssClass = "first-cell";
                Control ctrl1 = new Control();
                ctrl1 = new Label();
                ((Label)ctrl1).CssClass = "formLabel";
                ((Label)ctrl1).Text = "Nume utilizator: ";
                ((Label)ctrl1).Font.Bold = true;
                cell1.Controls.Add(ctrl1);
                row1.Cells.Add(cell1);

                //celula2
                TableCell cell2 = new TableCell();
                Control ctrl2 = new Control();
                ctrl2 = new Label();
                ((Label)ctrl2).CssClass = "formLabel";
                if (item.Alias != null)
                {
                    ((Label)ctrl2).Text = item.Alias;
                }
                else
                {
                    using (var db = new TheContext())
                    {
                        var userLastName = (from p in db.Users
                                            where p.UserId == item.UserId
                                            select p.LastName).SingleOrDefault();
                        var userFirstName = (from p in db.Users
                                             where p.UserId == item.UserId
                                             select p.FirstName).SingleOrDefault();

                        ((Label)ctrl2).Text = userLastName + " " + userFirstName;
                    }
                }
                ((Label)ctrl2).Font.Bold = true;
                cell2.Controls.Add(ctrl2);
                row1.Cells.Add(cell2);

                //randul 2
                TableRow row2 = new TableRow();

                //celula 3
                TableCell cell3 = new TableCell();
                Control ctrl3 = new Control();
                ctrl3 = new Label();
                ((Label)ctrl3).CssClass = "formLabel";
                ((Label)ctrl3).Text = "Comentariu: ";
                ((Label)ctrl3).Font.Bold = true;
                cell3.Controls.Add(ctrl3);
                row2.Cells.Add(cell3);

                //celula4
                TableCell cell4 = new TableCell();
                Control ctrl4 = new Control();

                ctrl4 = new TextBox();
                ((TextBox)ctrl4).CssClass = "form-control comment-textbox";
                ((TextBox)ctrl4).Text = item.Comment;
                ((TextBox)ctrl4).Font.Bold = true;
                ((TextBox)ctrl4).TextMode = TextBoxMode.MultiLine;
                ((TextBox)ctrl4).ReadOnly = true;

                Control ctrlx = new Control();
                ctrlx = new ImageButton();
                ((ImageButton)ctrlx).ImageUrl = "images/like.png";
                ((ImageButton)ctrlx).ID = reviewId.ToString();
                ((ImageButton)ctrlx).Click += ImageBtn_Click;
                ((ImageButton)ctrlx).CssClass = "like-image";
                
                //if (!AlreadyLiked(SessionUserId, reviewId))
                //{
                //    ((ImageButton)ctrlx).Enabled = false;
                //    ((ImageButton)ctrlx).ToolTip = "Ai dat deja like!";
                //    ((ImageButton)ctrlx).Style.Add(HtmlTextWriterStyle.Cursor, "not-allowed");
                //}
                

                Control ctrly = new Control();
                ctrly = new Label();
                ((Label)ctrly).CssClass = "like-count";

                using (var db = new TheContext())
                {
                    int countLikes = 0;

                    var likes = (from l in db.LikedReviews
                                 where l.ReviewId == reviewId
                                 select l.Like).ToList();

                    if (likes.Count == 0)
                    {
                        countLikes = 0;
                    }
                    else
                    {
                        for (int i = 0; i < likes.Count; i++)
                        {
                            countLikes++;
                        }
                    }
                    ((Label)ctrly).Text = countLikes.ToString();
                }


                cell4.Controls.Add(ctrl4);
                cell4.Controls.Add(ctrlx);
                cell4.Controls.Add(ctrly);
                row2.Cells.Add(cell4);

                //randul 3
                TableRow row3 = new TableRow();

                TableCell cell5 = new TableCell();
                Control ctrl5 = new Control();
                ctrl5 = new Label();
                ((Label)ctrl5).CssClass = "formLabel";
                ((Label)ctrl5).Text = "Scor: ";
                ((Label)ctrl5).Font.Bold = true;

                cell5.Controls.Add(ctrl5);
                row3.Cells.Add(cell5);



                TableCell cell6 = new TableCell();
                Control ctrl6 = new Control();
                ctrl6 = new Label();
                ((Label)ctrl6).CssClass = "formLabel";
                int nr_stele = item.NrStele;
                switch (nr_stele)
                {
                    case 1:
                        ((Label)ctrl6).Text = "<img src='images/rsz_1star.png'/>";
                        break;
                    case 2:
                        ((Label)ctrl6).Text = "<img src='images/rsz_2star.png'/>";
                        break;
                    case 3:
                        ((Label)ctrl6).Text = "<img src='images/rsz_3star.png'/>";
                        break;
                    case 4:
                        ((Label)ctrl6).Text = "<img src='images/rsz_4star.png'/>";
                        break;
                    case 5:
                        ((Label)ctrl6).Text = "<img src='images/rsz_5star.png'/>";
                        break;
                }

                ((Label)ctrl6).Font.Bold = true;
                cell6.Controls.Add(ctrl6);
                row3.Cells.Add(cell6);

                TableRow row4 = new TableRow();
                row4.BackColor = ColorTranslator.FromHtml("#333");

                TableCell cell7 = new TableCell();
                cell7.BorderColor = ColorTranslator.FromHtml("#333");
                row4.Cells.Add(cell7);

                TableCell cell8 = new TableCell();
                cell8.BorderColor = ColorTranslator.FromHtml("#333");

                row4.Cells.Add(cell8);

                tablerev.Rows.Add(row1);
                tablerev.Rows.Add(row2);
                tablerev.Rows.Add(row3);
                tablerev.Rows.Add(row4);
            }
            if (Session["USER_EMAIL"] != null)
            {
                addreview_btn.Visible = true;
            }
            else
            {
                addreview_btn.Visible = false;
            }
            if (addreview_btn.Visible == false)
            {
                loginstatus_lbl.Text = "Trebuie să fii logat înainte de a adăuga un review!";
            }
        }

        protected void ImageBtn_Click(object sender, ImageClickEventArgs e)
        {
            var id = int.Parse(Request.QueryString["id"]).ToString();

            ImageButton button = sender as ImageButton;
            string buttonId = button != null ? button.ID : null;
            int btnId = int.Parse(buttonId);

            if (Session["USER_EMAIL"] == null)
            {
                Response.Redirect("~/Logare.aspx");
            }
            else
            {
                using (var db = new TheContext())
                {
                    var likedReview = new LikedReview
                    {
                        ReviewId = btnId,
                        UserId = SessionUserId,
                        Like = 1
                    };
                    if (AlreadyLiked(SessionUserId, btnId))
                    {
                        var reviewLiked = ReturnExistLikedReview(SessionUserId, btnId);
                        db.LikedReviews.Attach(reviewLiked);
                        db.LikedReviews.Remove(reviewLiked);
                        db.SaveChanges();
                    }
                    else
                    {
                        db.LikedReviews.Add(likedReview);
                        db.SaveChanges();
                    }
                    
                    
                }

                Response.Redirect("~/viewreviews.aspx?id=" + id);
            }
        }


        protected void addreview_btn_Click(object sender, EventArgs e)
        {
            var id = int.Parse(Request.QueryString["id"]).ToString();
            Response.Redirect("~/addreview.aspx?id=" + id);
            addreview_btn.Font.Bold = true;
        }

        protected void admin_btn_Click(object sender, EventArgs e)
        {
            var id = int.Parse(Request.QueryString["id"]).ToString();
            Response.Redirect("AdminPage.aspx?id=" + id);
        }
    }
}