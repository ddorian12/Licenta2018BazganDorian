﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Contextul;

namespace webforms
{
    public partial class _1 : System.Web.UI.Page
    {
        
        public List<Firma> SelectFirmas()
        {
            var id = int.Parse(Request.QueryString["id"]);
            using (var db = new TheContext())
            {
                var firme = (from f in db.Firme
                             where f.Categorie.CategoryId == id
                             select f).ToList();
                return firme;
            }
        }

        public int GetFirmScore(int id)
        {
            var rankFirma = 0;
            using (var db = new TheContext())
            {
                var reviews = (from r in db.Reviews
                               where r.FirmaId == id
                               select r).ToList();
                foreach (var r in reviews)
                {
                    rankFirma += r.NrStele / reviews.Count;
                }
            }
            return rankFirma;
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            var firme = SelectFirmas();

            foreach (var f in firme)
            {
                var rank = GetFirmScore(f.FirmaId);

                TableRow row2 = new TableRow();

                TableCell cell1 = new TableCell();
                Control ctrl1 = new Control();
                ctrl1 = new Label();
                ((Label)ctrl1).CssClass = "formLabel";
                ((Label) ctrl1).Text = f.Nume + "<br/>";
                if (rank == 0)
                {
                    ((Label) ctrl1).Text += "<img src='images/rsz_0star.png'/>";
                }
                else
                {
                    switch (rank)
                    {
                        case 1:
                            ((Label)ctrl1).Text += "<img src='images/rsz_1star.png'/>";
                            break;
                        case 2:
                            ((Label)ctrl1).Text += "<img src='images/rsz_2star.png'/>";
                            break;
                        case 3:
                            ((Label)ctrl1).Text += "<img src='images/rsz_3star.png'/>";
                            break;
                        case 4:
                            ((Label)ctrl1).Text += "<img src='images/rsz_4star.png'/>";
                            break;
                        case 5:
                            ((Label)ctrl1).Text += "<img src='images/rsz_5star.png'/>";
                            break;
                    }
                }
                
                ((Label)ctrl1).Font.Bold = true;

                cell1.Controls.Add(ctrl1);
                row2.Cells.Add(cell1);

                TableCell cell2 = new TableCell();
                Control ctrl2 = new Control();
                ctrl2 = new HyperLink();
                ((HyperLink)ctrl2).CssClass = "formLabel";
                ((HyperLink)ctrl2).Text = "Detalii firmă " + "<div class='glyphicon glyphicon-chevron-right'></div>";
                ((HyperLink)ctrl2).Font.Bold = true;
                ((HyperLink) ctrl2).NavigateUrl = "DetailsFirme.aspx?id=" + f.FirmaId; 
                cell2.Controls.Add(ctrl2);
                row2.Cells.Add(cell2);

                TableCell cell3 = new TableCell();
                Control ctrl3 = new Control();
                ctrl3 = new HyperLink();
                ((HyperLink)ctrl3).CssClass = "formLabel";
                ((HyperLink)ctrl3).Text = "Vezi review-uri " + "<div class='glyphicon glyphicon-chevron-right'></div>";
                ((HyperLink)ctrl3).Font.Bold = true;
                ((HyperLink) ctrl3).NavigateUrl = "viewreviews.aspx?id=" + f.FirmaId;
                cell3.Controls.Add(ctrl3);
                row2.Cells.Add(cell3);

                tabelFirme.Rows.Add(row2);

            }
        }
    }
}