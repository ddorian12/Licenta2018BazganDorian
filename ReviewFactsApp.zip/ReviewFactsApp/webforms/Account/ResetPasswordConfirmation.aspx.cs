﻿using System.Web.UI;

namespace webforms.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}