﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Contextul;

namespace webforms
{
    public partial class AdminPage : System.Web.UI.Page
    {
        public string PageId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            PageId = int.Parse(Request.QueryString["id"]).ToString();
        }

        protected void deleteuser_btn_Click(object sender, EventArgs e)
        {
            var email = deleteEmail_textbox.Text;
            using (var db = new TheContext())
            {
                var user = (from u in db.Users
                            where u.Email == email
                            select u).SingleOrDefault();
                if (user != null)
                {
                    
                    var likedRev = db.LikedReviews.Where(l => l.UserId == user.UserId);
                    db.LikedReviews.RemoveRange(likedRev);

                    var allReviews = db.Reviews.Where(r => r.UserId == user.UserId);
                    foreach(var rev in allReviews)
                    {
                        var likedReviews = db.LikedReviews.Where(lr => lr.ReviewId == rev.ReviewId);
                        db.LikedReviews.RemoveRange(likedReviews);
                    }
                    
                    db.Reviews.RemoveRange(allReviews);
                    db.Users.Remove(user);
                    db.SaveChanges();

                    Session.Remove("USER_EMAIL");
                    status_lbl.Text = "Done!";
                }
                else
                {
                    status_lbl.Text = "Nu exista user asociat cu email-ul introdus!";
                }
            }
            
        }

        protected void deletereview_btn_Click(object sender, EventArgs e)
        {
            var idString = deletereviewid_textbox.Text;
            var _id = int.Parse(idString);

            using (var db = new TheContext())
            {
                var allLikes = db.LikedReviews.Where(l => l.ReviewId == _id);

                var review = (from u in db.Reviews
                              where u.ReviewId == _id
                              select u).SingleOrDefault();

                db.LikedReviews.RemoveRange(allLikes);

                if (review != null)
                {
                    db.Reviews.Remove(review);
                }

                db.SaveChanges();
            }
            Response.Redirect("AdminPage.aspx?id=" + PageId);
        }

        protected void aprove_btn_Click(object sender, EventArgs e)
        {
            var idStr = deletereviewid_textbox.Text;
            var _id = int.Parse(idStr);

            using (var db = new TheContext())
            {
                var review = (from r in db.Reviews
                              where r.ReviewId == _id
                              select r).SingleOrDefault();
                if (review != null)
                {
                    review.Approved = 1;
                    db.SaveChanges();
                }
            }
        }


        protected void toreviews_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("viewreviews.aspx?id=" + PageId);
        }
    }
}