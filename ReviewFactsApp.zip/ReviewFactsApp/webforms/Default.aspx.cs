﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.Script.Services;
using System.Web.Services;
using Contextul;
using System.Data.Entity;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Web.Script.Serialization;
using Microsoft.Ajax.Utilities;

namespace webforms
{
    public partial class _Default : Page
    {
        private static TheContext _context;
        viewreviews obj = new viewreviews();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (login_label != null)
            {
                if (Session["USER_EMAIL"] != null)
                {
                    login_label.Text = Session["USER_EMAIL"].ToString() + " te-ai logat cu succes!";
                    obj.GetUserId();
                }
                else
                {
                    login_label.Text = "Nu esti logat!";
                }
            }
        }

        protected void logout_btn_Click(object sender, EventArgs e)
        {
            Session.Remove("USER_EMAIL");
            Response.Redirect("Default.aspx");
        }

        public static bool HasKeyword(string review, Dictionary<string, List<string>> trainingDocuments)
        {
            List<string> words = trainingDocuments.SelectMany(x => x.Value).ToList();
            List<string> wordsFromReview = review.Split(' ').ToList();

            foreach (var word in wordsFromReview)
            {
                if (words.Contains(word))
                {
                    return true;
                }
            }
            return false;
        }

        //datele de antrenament pentru clasificarea review-urilor
        static List<Document> trainDataCategories = new List<Document>
        {
            new Document("mobila",
                "masa mesei masuta masutei comoda comodei biblioteca bibliotecii PAL nuc fag extensibil rectangular picioare finisaje lac lemn imbinari lac nitrolac slefuit incleiat fin"),
            new Document("constructii",
                "beton betonului nisip nisipului var varului fier fierului etrier trotuar tencuiala finisare finisaj manopera acoperis etriere caramida ciment materiale BCA bca sarma striat"),
            new Document("foraje fantani",
                "freza frezei apa apei huma lut lutului var fantana piatra motor motorului metri metru m tuburi margaritar cm centimetri forat foraj sol pamant")
        };

        //datele de antrenament pentru clasificarea domeniilor
        private static List<Document> trainDataDomains = new List<Document>
        {
            new Document("mobila",
                "dormitoare dormitor bucatarie bucatarii baie bai living sufragerie sufragerii"),
            new Document("constructii",
                "case casa acoperis magazie magazii beci beciuri anexe anexa cabana cabane"),
            new Document("foraje fantani",
                "puturi fantani arterziana fantana put")
        };


        //returneaza lista de cuvinte pentru o anumita categorie
        public static List<string> GetWordsForCategory(string category, List<Document> corpus)
        {
            var docsFromCorpus = corpus.Where(c => c.TheClass == category).Select(d => d.Sentence)
                .Aggregate((i, j) => i + ' ' + j);

            List<string> wordsForClassName = Regex.Replace(docsFromCorpus, "\\p{P}+", "").Split(' ').ToList();

            return wordsForClassName;
        }

        //maparea documentului cu datele de antrenament
        public static Dictionary<string, List<string>> MapTrainingData(List<Document> corpus)
        {
            Dictionary<string, List<string>> trainingData = new Dictionary<string, List<string>>();

            trainingData.Add("mobila", GetWordsForCategory("mobila", corpus));
            trainingData.Add("constructii", GetWordsForCategory("constructii", corpus));
            trainingData.Add("foraje fantani", GetWordsForCategory("foraje fantani", corpus));

            return trainingData;
        }

        public static Dictionary<string, List<string>> TrainingDictionaryDataReviews =
            MapTrainingData(trainDataCategories);

        public static Dictionary<string, List<string>>
            TrainingDictionaryDataDomains = MapTrainingData(trainDataDomains);

        //calculeaza numarul de aparatii a fiecarui cuvant din datele de antrenament
        public static Dictionary<string, int> CountingWords(Dictionary<string, List<string>> trainingDocuments)
        {
            Dictionary<string, int> countingWords = new Dictionary<string, int>();

            List<string> words = trainingDocuments.SelectMany(x => x.Value).ToList();

            foreach (var word in words)
            {
                if (countingWords.ContainsKey(word))
                {
                    countingWords[word]++;
                }
                else
                {
                    countingWords.Add(word, 1);
                }
            }

            return countingWords;
        }

        public static double CalculateScoreForClass(string sentence, string className,
            Dictionary<string, List<string>> corpus)
        {
            double probability = 0;
            var countWords = CountingWords(corpus);

            List<string> wordsForClass = corpus.Where(x => x.Key == className).SelectMany(x => x.Value).ToList();

            List<string> wordsFromReview = Regex.Replace(sentence, "\\p{P}+", "").Split(' ').ToList();

            foreach (var word in wordsFromReview)
            {
                if (wordsForClass.Contains(word))
                {
                    probability += 1 / (double) countWords[word.ToLower()];
                }
            }

            return probability;
        }

        public static string Classify(string sentence, Dictionary<string, List<string>> corpusDictionary)
        {
            Dictionary<string, double> classificationDictionary = new Dictionary<string, double>();
            var hasCategoryKeyword = HasKeyword(sentence, TrainingDictionaryDataReviews);
            var hasDomainKeyword = HasKeyword(sentence, TrainingDictionaryDataDomains);

            foreach (var @class in corpusDictionary.Keys)
            {
                var probability = CalculateScoreForClass(sentence, @class, corpusDictionary);
                classificationDictionary.Add(@class, probability);
            }
           
            if (hasCategoryKeyword || hasDomainKeyword)
            {
                var classifiedCategory = classificationDictionary
                    .FirstOrDefault(x => Math.Abs(x.Value - classificationDictionary.Values.Max()) < 0.01).Key;
                return classifiedCategory;
            }
            return "Nici o potrivire";
        }

        public static int GetCategoryId(string category)
        {
            if (category == "constructii")
            {
                return 1;
            }

            if (category == "mobila")
            {
                return 2;
            }

            if (category == "foraje fantani")
            {
                return 3;
            }
            return 0;
        }

        public bool CanSubmitDefault(int userId, int firmaId)
        {
            using (var db = new TheContext())
            {
                var review = (from r in db.Reviews
                    where r.FirmaId == firmaId
                    where r.UserId == viewreviews.SessionUserId
                    select r).SingleOrDefault();
                if (review != null)
                {
                    return false;
                }
                return true;
            }
        }

        public int GetFirmIdByName(string name)
        {
            using (var db = new TheContext())
            {
                var id = (from f in db.Firme
                    where f.Nume == name
                    select f.FirmaId).SingleOrDefault();
                return id;
            }
        }

        [WebMethod]
        public static List<Firma> LoadData(string myCategory)
        {
            var categoryId = GetCategoryId(myCategory);
            _context = new TheContext();
            var firme = _context.Firme.Include(x => x.Categorie).Where(x => x.Categorie.CategoryId == categoryId)
                .ToList();
            return firme;
        }


        public static string GetFirmasByDomain(string searchInput)
        {
            var finalClassification = string.Empty;
            if (searchInput != string.Empty && HasKeyword(searchInput, TrainingDictionaryDataDomains))
            {
                finalClassification = Classify(searchInput, TrainingDictionaryDataDomains);
            }
            return finalClassification;
        }

        [WebMethod]
        public static string ReviewValue(string myReview)
        {
            var finalClassification = string.Empty;
            
            if (myReview != string.Empty)
            {
                finalClassification = Classify(myReview, TrainingDictionaryDataReviews);
            }
            
            return finalClassification;
        }

        protected void btnSearchBox_Click(object sender, EventArgs e)
        {
            var userSearch = Request.Form[searchBox.UniqueID];
            var hasKeyword = HasKeyword(userSearch, TrainingDictionaryDataDomains);
            if (userSearch.IsNullOrWhiteSpace() || !hasKeyword)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                var bayesClassification = GetFirmasByDomain(userSearch);
                var categoryId = GetCategoryId(bayesClassification);
                Response.Redirect("1.aspx?id=" + categoryId);
            }
            
        }

        protected void submitReview_LinkBtn_Click(object sender, EventArgs e)
        {
            if (Session["USER_EMAIL"] == null)
            {
                Response.Redirect("~/Logare.aspx");
            }
            else
            {
                int rating;
                string selectedValue = Request.Form[firmeDropdownList.UniqueID];
                var comment = classifyReviewTextarea.Value;
                var firmaId = GetFirmIdByName(selectedValue);
                var hasRating = int.TryParse(rblMeasurementClassification.SelectedValue, out rating);

                if (firmaId == 0)
                {
                    successLabel.Text = "Nu exista firma!";
                }
                else
                {
                    if (comment == string.Empty)
                    {
                        successLabel.Text = "Trebuie sa adaugi un comentariu!";
                    }
                    else if (!hasRating)
                    {
                        successLabel.Text = "Trebuie sa alegi un numar de stele!";
                    }
                    else
                    {
                        if (CanSubmitDefault(viewreviews.SessionUserId, firmaId))
                        {
                            using (var db = new TheContext())
                            {
                                var review = new Review
                                {
                                    FirmaId = firmaId,
                                    UserId = viewreviews.SessionUserId,
                                    Comment = comment,
                                    NrStele = rating
                                };
                                db.Reviews.Add(review);
                                db.SaveChanges();
                            }
                            classifyReviewTextarea.Value = string.Empty;
                            successLabel.Text =
                                "Review-ul a fost adaugat cu succes! Va aparea in sectiune de review-uri dupa aprobarea unui admin.";
                        }
                        else
                        {
                            successLabel.Text = "Ai mai adaugat un review la firma selectata!";
                        }

                    }
                }
            }
        }
    }
    public class Document
    {
        public string TheClass { get; set; }
        public string Sentence { get; set; }

        public Document(string theClass, string sentence)
        {
            TheClass = theClass;
            Sentence = sentence;
        }
    }
}