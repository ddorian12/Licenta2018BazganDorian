﻿using Contextul;
using System;
using System.Linq;

namespace webforms
{
    public partial class testtable : System.Web.UI.Page
    {
        string[] SelectFirma(int id)
        {
            using (var db = new TheContext())
            {
                var firma = (from f in db.Firme
                    where f.FirmaId == id
                    select f).Single();
                string[] s1 = new string[3];
                s1[0] = firma.Nume;
                s1[1] = firma.Sediu;
                s1[2] = firma.Descriere;
                return s1;
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            var _id = int.Parse(Request.QueryString["id"]);
            string[] s2 = SelectFirma(_id);
            numefirma_lbl.Text = s2[0];
            locatiefirma_lbl.Text = s2[1];
            descriere_txb.Text = s2[2];
        }
    }
}