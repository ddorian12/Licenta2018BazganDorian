﻿/// <reference path="jquery-1.12.0.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="respond.js" />
