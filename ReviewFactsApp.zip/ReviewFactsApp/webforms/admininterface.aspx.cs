﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Contextul;

namespace webforms
{
    public partial class admininterface : System.Web.UI.Page
    {
        public string PageId { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            PageId = int.Parse(Request.QueryString["id"]).ToString();
        }

        protected void deleteuser_btn_Click(object sender, EventArgs e)
        {
            var email = deleteEmail_textbox.Text;
            using (var db = new TheContext())
            {
                var user = (from u in db.Users
                    where u.Email == email
                    select u).SingleOrDefault();
                db.Users.Remove(user);
                db.SaveChanges();
            }
            status_lbl.Text = "Done!";
        }

        protected void deletereview_btn_Click(object sender, EventArgs e)
        {
            var idString = deletereviewid_textbox.Text;
            var _id = int.Parse(idString);

            using (var db = new TheContext())
            {
                var likedReview = (from lr in db.LikedReviews
                    where lr.ReviewId == _id
                    select lr).SingleOrDefault();
                var review = (from u in db.Reviews
                    where u.ReviewId == _id
                    select u).SingleOrDefault();
                if (likedReview != null)
                {
                    db.LikedReviews.Remove(likedReview);
                }
                db.Reviews.Remove(review);
                db.SaveChanges();
            }
            Response.Redirect("admininterface.aspx?id=" + PageId);
        }

        protected void aprove_btn_Click(object sender, EventArgs e)
        {
            var idStr = deletereviewid_textbox.Text;
            var _id = int.Parse(idStr);

            using (var db = new TheContext())
            {
                var review = (from r in db.Reviews
                    where r.ReviewId == _id
                    select r).SingleOrDefault();
                if (review != null)
                {
                    review.Approved = 1;
                    db.SaveChanges();
                }
            }
        }


        protected void toreviews_btn_Click(object sender, EventArgs e)
        {
            Response.Redirect("viewreviews.aspx?id=" + PageId);
        }
    }
}