﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Contextul
{
    public class TheContext : DbContext
    {
        public TheContext()
        {

        }

        public DbSet<Review> Reviews { get; set; }
        public DbSet<Firma> Firme { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<LikedReview> LikedReviews { get; set; }
        public DbSet<Category> Categories { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
    public class Firma
    {
        public int FirmaId { get; set; }
        public int? CategoryId { get; set; }
        public string Nume { get; set; }
        public string Sediu { get; set; }
        public string Descriere { get; set; }
        [ScriptIgnore(ApplyToOverrides = true)]
        public virtual Category Categorie { get; set; }
        [ScriptIgnore(ApplyToOverrides = true)]
        public virtual ICollection<Review> ReviewurileFirmei { get; set; }
        public Firma()
        {
            ReviewurileFirmei = new HashSet<Review>();
        }

    }

    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public virtual ICollection<Firma> ListOfFirmas { get; set; }

        public Category()
        {
            ListOfFirmas = new HashSet<Firma>();
        }
    }

    public class User
    {
        public int UserId { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string AccessMember { get; set; }
        public byte[] Salt { get; set; }
        public virtual ICollection<Review> ReviewsPerUser { get; set; }
        public virtual ICollection<LikedReview> LikesPerUser { get; set; }

        public User()
        {
            ReviewsPerUser = new HashSet<Review>();
            LikesPerUser = new HashSet<LikedReview>();
        }
    }

    public class Review
    {
        public int ReviewId { get; set; }
        [Required]
        public int? FirmaId { get; set; }
        public int? UserId { get; set; }
        [DataType(DataType.MultilineText)]
        public string Comment { get; set; }
        [Required]
        public int NrStele { get; set; }
        [Required]
        public int Approved { get; set; }
        public virtual Firma Firma { get; set; }
        public virtual User User { get; set; }
        public virtual ICollection<LikedReview> LikesForReview { get; set; }
        public string Alias { get; set; }

        public Review()
        {
            LikesForReview = new HashSet<LikedReview>();
        }
    }
    public class LikedReview
    {
        public int LikedReviewId { get; set; }
        public int? ReviewId { get; set; }
        public int? UserId { get; set; }
        public int Like { get; set; }
        public virtual Review ReviewForLike { get; set; }
        public virtual User UserForLike { get; set; }
    }
}
