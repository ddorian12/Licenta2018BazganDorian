namespace Contextul.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Contextul.TheContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Contextul.TheContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            context.Firme.AddOrUpdate(
                new Firma { CategoryId = 1, Descriere = "Firma cu sediul in Vaslui", Nume = "Firma1", Sediu = "Vaslui"},
                new Firma { CategoryId = 1, Descriere = "Firma cu sediul in Iasi", Nume = "Firma2", Sediu = "Iasi"},
                new Firma { CategoryId = 2, Descriere = "Firma din Botosani", Nume = "Firma3", Sediu = "Botosani" },
                new Firma { CategoryId = 2, Descriere = "Firma din Galati", Nume = "Firma4", Sediu = "Galati" },
                new Firma { CategoryId = 3, Descriere = "Firma cu sediul in Ploiesti", Nume = "Firma5", Sediu = "Ploiesti" },
                new Firma { CategoryId = 3, Descriere = "Firma cu sediul in Pitesti", Nume = "Firma6", Sediu = "Pitesti" }
                );

            context.Categories.AddOrUpdate(
                new Category { CategoryName = "constructii"},
                new Category { CategoryName = "mobila" },
                new Category { CategoryName = "foraje fantani" }
                );
        }
    }
}
