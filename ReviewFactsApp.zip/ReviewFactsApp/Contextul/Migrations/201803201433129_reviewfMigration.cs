namespace Contextul.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class reviewfMigration : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Firmas",
                c => new
                    {
                        FirmaId = c.Int(nullable: false, identity: true),
                        Nume = c.String(),
                        Sediu = c.String(),
                        Descriere = c.String(),
                    })
                .PrimaryKey(t => t.FirmaId);
            
            CreateTable(
                "dbo.Reviews",
                c => new
                    {
                        ReviewId = c.Int(nullable: false, identity: true),
                        FirmaId = c.Int(nullable: false),
                        UserId = c.Int(),
                        Comment = c.String(),
                        NrStele = c.Int(nullable: false),
                        Approved = c.Int(nullable: false),
                        Alias = c.String(),
                    })
                .PrimaryKey(t => t.ReviewId)
                .ForeignKey("dbo.Firmas", t => t.FirmaId, cascadeDelete: true)
                .ForeignKey("dbo.Users", t => t.UserId)
                .Index(t => t.FirmaId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.LikedReviews",
                c => new
                    {
                        LikedReviewId = c.Int(nullable: false, identity: true),
                        ReviewId = c.Int(),
                        UserId = c.Int(),
                        Like = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.LikedReviewId)
                .ForeignKey("dbo.Reviews", t => t.ReviewId)
                .ForeignKey("dbo.Users", t => t.UserId)
                .Index(t => t.ReviewId)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserId = c.Int(nullable: false, identity: true),
                        LastName = c.String(),
                        FirstName = c.String(),
                        Email = c.String(),
                        Password = c.String(),
                        AccessMember = c.String(),
                        Salt = c.Binary(),
                    })
                .PrimaryKey(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Reviews", "UserId", "dbo.Users");
            DropForeignKey("dbo.LikedReviews", "UserId", "dbo.Users");
            DropForeignKey("dbo.LikedReviews", "ReviewId", "dbo.Reviews");
            DropForeignKey("dbo.Reviews", "FirmaId", "dbo.Firmas");
            DropIndex("dbo.LikedReviews", new[] { "UserId" });
            DropIndex("dbo.LikedReviews", new[] { "ReviewId" });
            DropIndex("dbo.Reviews", new[] { "UserId" });
            DropIndex("dbo.Reviews", new[] { "FirmaId" });
            DropTable("dbo.Users");
            DropTable("dbo.LikedReviews");
            DropTable("dbo.Reviews");
            DropTable("dbo.Firmas");
        }
    }
}
